from django.shortcuts import render
from django.views.generic import TemplateView
from projects.models import Projeto # Agora podemos importar

class HomePageView(TemplateView):
    template_name = "core/home.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Passaremos as dietas para o template da home page
        # Buscamos projetos marcados como destaque, ordenados por data e limitados a 4
        context['featured_projects'] = Projeto.objects.filter(destaque=True).order_by('-data_criacao')[:4]
        context['page_title'] = "Minhas Dietas"
        context['author_phrase'] = "Um site feito para ajuda nutricionista"
        return context 