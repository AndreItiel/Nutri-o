from django.db.models import Q
from django.urls import reverse_lazy
from django.views.generic import (
    ListView, DetailView, CreateView, UpdateView, DeleteView
)
from .models import Projeto, Tecnologia
from .forms import ProjetoForm

class ProjectListView(ListView):
    model = Projeto
    template_name = 'projects/project_list.html'
    context_object_name = 'projects'
    paginate_by = 100 # Paginação com 100 dietas por página

    def get_queryset(self):
        queryset = super().get_queryset().select_related(None).prefetch_related('tecnologias') # Otimização
        query = self.request.GET.get('q')
        tech_filter = self.request.GET.get('tecnologia')
        sort_by = self.request.GET.get('sort', '-data_criacao') # Padrão: mais recentes primeiro

        if query:
            queryset = queryset.filter(
                Q(titulo__icontains=query) | Q(descricao__icontains=query)
            )
        
        if tech_filter:
            try:
                tecnologia = Tecnologia.objects.get(nome__iexact=tech_filter)
                queryset = queryset.filter(tecnologias=tecnologia)
            except Tecnologia.DoesNotExist:
                pass # Ou poderia retornar queryset.none() ou uma mensagem

        if sort_by in ['titulo', '-titulo', 'data_criacao', '-data_criacao']:
            queryset = queryset.order_by(sort_by)
        
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['tecnologias'] = Tecnologia.objects.all()
        context['current_query'] = self.request.GET.get('q', '')
        context['current_tech'] = self.request.GET.get('tecnologia', '')
        context['current_sort'] = self.request.GET.get('sort', '-data_criacao')
        return context


class ProjectDetailView(DetailView):
    model = Projeto
    template_name = 'projects/project_detail.html'
    context_object_name = 'project'

    def get_queryset(self):
        # Otimizar a consulta para buscar tecnologias relacionadas
        return super().get_queryset().prefetch_related('tecnologias')


class ProjectCreateView(CreateView):
    model = Projeto
    form_class = ProjetoForm
    template_name = 'projects/project_form.html'
    # success_url = reverse_lazy('projects:project-list') # Usaremos get_success_url no form para redirecionar ao detalhe

    def get_success_url(self):
        return reverse_lazy('projects:project-detail', kwargs={'pk': self.object.pk})

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Adicionar Nova Dieta"
        return context


class ProjectUpdateView(UpdateView):
    model = Projeto
    form_class = ProjetoForm
    template_name = 'projects/project_form.html'

    def get_success_url(self):
        return reverse_lazy('projects:project-detail', kwargs={'pk': self.object.pk})

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f"Editar Projeto: {self.object.titulo}"
        return context


class ProjectDeleteView(DeleteView):
    model = Projeto
    template_name = 'projects/project_confirm_delete.html'
    success_url = reverse_lazy('projects:project-list')
    context_object_name = 'project'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f"Confirmar Exclusão: {self.object.titulo}"
        return context 