from django.contrib import admin
from .models import Tecnologia, Projeto

@admin.register(Tecnologia)
class TecnologiaAdmin(admin.ModelAdmin):
    list_display = ('nome', 'cor')
    list_filter = ('cor',)
    search_fields = ('nome',)

@admin.register(Projeto)
class ProjetoAdmin(admin.ModelAdmin):
    list_display = ('titulo', 'data_criacao', 'link_aplicacao')
    list_filter = ('data_criacao', 'tecnologias')
    search_fields = ('titulo', 'descricao')
    filter_horizontal = ('tecnologias',) 