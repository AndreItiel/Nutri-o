# Portfólio Dinâmico com Django

Este projeto é um portfólio dinâmico construído com Django, permitindo ao usuário apresentar seus projetos de forma organizada e interativa. Ele foi desenvolvido para ser flexível, com funcionalidades de CRUD para projetos, categorização por tecnologias, e uma interface responsiva.

## Tecnologias Utilizadas

*   **Backend:** Django (Python)
*   **Banco de Dados:** PostgreSQL
*   **Frontend:** HTML, CSS, Bootstrap 5
*   **Gerenciamento de Pacotes:** Pip
*   **Variáveis de Ambiente:** `python-dotenv`

## Funcionalidades Principais

*   **App `core`:**
    *   Página inicial (`HomePageView`) exibindo projetos em destaque e uma frase do autor.
*   **App `projects`:**
    *   **Modelos:**
        *   `Tecnologia`: Armazena tecnologias (ex: Python, Django) com um campo `cor` para definir a cor do badge (usando classes do Bootstrap).
        *   `Projeto`: Detalhes dos projetos, incluindo título, descrição, imagem, links (repositório, aplicação), data, e um relacionamento ManyToMany com `Tecnologia`. Possui um campo booleano `destaque`.
    *   **CRUD Completo para Projetos:**
        *   Utiliza Class-Based Views (CBVs): `ProjectListView`, `ProjectDetailView`, `ProjectCreateView`, `ProjectUpdateView`, `ProjectDeleteView`.
        *   Formulário `ProjetoForm` para criação e edição, utilizando `ModelMultipleChoiceField` com `CheckboxSelectMultiple` para seleção de tecnologias.
    *   **Listagem de Projetos (`ProjectListView`):**
        *   Paginação.
        *   Busca por palavra-chave no título ou descrição.
        *   Filtro por tecnologia específica.
        *   Ordenação por data de criação ou título (ascendente/descendente).
    *   **Detalhes do Projeto (`ProjectDetailView`):** Exibe todas as informações do projeto, incluindo as tecnologias associadas.
    *   **Administração Django:**
        *   Modelos `Tecnologia` e `Projeto` registrados.
        *   Personalização para facilitar a edição, incluindo `filter_horizontal` para tecnologias em projetos e a exibição/edição do campo `cor` em tecnologias.
*   **Templates:**
    *   Estrutura base (`base.html`) com Bootstrap 5, header e footer.
    *   Templates específicos para cada view (home, lista de projetos, detalhe do projeto, formulário, confirmação de exclusão).
    *   Herança de templates para reuso de código.
*   **Template Tags Personalizadas (`projects/templatetags/project_tags.py`):**
    *   `join_technologies`: Explicação detalhada abaixo.
    *   `project_card_class`: Exemplo para alternar classes em cards.
*   **Arquivos Estáticos:** CSS customizado (`static/css/style.css`) e placeholders de imagem.
*   **Comando de Gerenciamento:** `createsuperuser_custom` para criar um superusuário padrão (`admin`/`admin123`).
*   **Configuração:**
    *   Uso de `python-dotenv` para gerenciar variáveis de ambiente (`.env`).
    *   Configuração para PostgreSQL.
    *   Internacionalização e localização para `pt-BR`.

## Implementação Detalhada: Balões Coloridos de Tecnologias

Uma das funcionalidades visuais chave é a exibição das tecnologias associadas a cada projeto como "balões" (badges do Bootstrap) coloridos. Isso foi alcançado da seguinte forma:

1.  **Modelo `Tecnologia` Atualizado:**
    *   No arquivo `projects/models.py`, o modelo `Tecnologia` foi estendido para incluir um campo `cor`:
        ```python
        class Tecnologia(models.Model):
            nome = models.CharField(max_length=50, unique=True, verbose_name="Nome da Tecnologia")
            COR_CHOICES = [
                ('primary', 'Azul Primário'),
                ('secondary', 'Cinza Secundário'),
                # ... outras cores ...
                ('dark', 'Preto/Cinza Escuro'),
            ]
            cor = models.CharField(
                max_length=10,
                choices=COR_CHOICES,
                default='secondary',
                help_text="Escolha uma cor para o badge da tecnologia."
            )
            # ...
        ```
    *   O campo `cor` utiliza `choices` para apresentar uma lista pré-definida de classes de cores do Bootstrap (ex: `primary`, `success`, `warning`). Isso garante consistência e facilita a seleção no painel de administração.

2.  **Painel de Administração:**
    *   Em `projects/admin.py`, a classe `TecnologiaAdmin` foi configurada para exibir e permitir a edição do campo `cor`, permitindo ao administrador associar uma cor a cada tecnologia.

3.  **Template Tag Personalizada `join_technologies`:**
    *   Localizada em `projects/templatetags/project_tags.py`, esta tag de filtro é o coração da funcionalidade.
    *   Ela recebe o queryset de tecnologias relacionadas a um projeto (ex: `project.tecnologias.all()`).
    *   Se existirem tecnologias, a tag itera sobre cada objeto `tech` na coleção.
    *   Para cada tecnologia, ela acessa `tech.nome` (o nome da tecnologia) e `tech.cor` (a classe de cor definida no admin).
    *   Utilizando `django.utils.html.format_html_join` (ou `format_html` para cada item), ela constrói dinamicamente a string HTML para cada badge. O HTML gerado para um badge é similar a:
        ```html
        <span class="badge bg-{cor_da_tecnologia} me-1">{nome_da_tecnologia}</span>
        ```
        Por exemplo, se uma tecnologia "Python" tiver a cor "primary" associada, o HTML seria:
        `<span class="badge bg-primary me-1">Python</span>`
    *   A função da tag retorna a concatenação de todos esses badges HTML. Se não houver tecnologias, retorna uma mensagem indicando isso.

4.  **Uso nos Templates:**
    *   Nos templates onde os balões são necessários (ex: `templates/core/home.html` para projetos em destaque, `templates/projects/project_list.html` para os cards na lista, e `templates/projects/project_detail.html` para a página de detalhes), a tag é chamada da seguinte forma:
        ```html
        {% load project_tags %}  <!-- No topo do template -->

        <!-- ... dentro do loop de projetos ... -->
        {{ project.tecnologias|join_technologies|safe }}
        ```
    *   **`project.tecnologias`**: Acessa o manager ManyToMany do objeto projeto.
    *   **`|join_technologies`**: Aplica nosso filtro personalizado.
    *   **`|safe`**: Este filtro é crucial. Como a templatetag retorna uma string HTML, o filtro `safe` instrui o Django a não escapar esse HTML, permitindo que ele seja renderizado corretamente como badges no navegador, em vez de exibir as tags HTML como texto literal.

Este processo permite uma maneira flexível e administrável de exibir visualmente as tecnologias de cada projeto com cores distintas, melhorando a interface do usuário.

## Outras Funcionalidades Detalhadas

Além dos balões de tecnologia, outras funcionalidades importantes foram implementadas:

### 1. Filtragem e Ordenação na Lista de Projetos (`ProjectListView`)

A listagem de projetos em `projects/views.py` (classe `ProjectListView`) oferece recursos robustos de filtragem e ordenação:

*   **Como Funciona:** A view intercepta parâmetros GET da URL (ex: `?q=palavra&tecnologia=Python&sort=titulo`).
*   **Busca por Palavra-Chave (`q`):**
    *   Utiliza `Q` objects do Django (`django.db.models.Q`) para realizar uma busca `icontains` (case-insensitive) no campo `titulo` e `descricao` do modelo `Projeto`.
    *   Exemplo de código em `get_queryset` dentro de `ProjectListView`:
        ```python
        if query: # query = self.request.GET.get('q')
            queryset = queryset.filter(
                Q(titulo__icontains=query) | Q(descricao__icontains=query)
            )
        ```
*   **Filtro por Tecnologia (`tecnologia`):
    *   Busca um objeto `Tecnologia` pelo nome exato (case-insensitive) fornecido.
    *   Filtra o queryset de projetos para incluir apenas aqueles que têm a tecnologia especificada em seu relacionamento ManyToMany `tecnologias`.
    *   Exemplo:
        ```python
        if tech_filter: # tech_filter = self.request.GET.get('tecnologia')
            try:
                tecnologia = Tecnologia.objects.get(nome__iexact=tech_filter)
                queryset = queryset.filter(tecnologias=tecnologia)
            except Tecnologia.DoesNotExist:
                pass # Ignora se a tecnologia não existir
        ```
*   **Ordenação (`sort`):
    *   Permite ordenar por `titulo` (ascendente/descendente) e `data_criacao` (ascendente/descendente, que é o padrão para "Mais Recentes" com `-data_criacao`).
    *   O valor do parâmetro `sort` é passado diretamente para o método `order_by()` do queryset, após validação para garantir que são campos permitidos.
    *   Exemplo:
        ```python
        sort_by = self.request.GET.get('sort', '-data_criacao')
        if sort_by in ['titulo', '-titulo', 'data_criacao', '-data_criacao']:
            queryset = queryset.order_by(sort_by)
        ```
*   **Interface no Template:** O template `templates/projects/project_list.html` contém um formulário com campos `<input>` para busca e `<select>` para tecnologia e ordenação, que submetem os parâmetros via GET para a própria view.

### 2. Paginação na Lista de Projetos

A `ProjectListView` também implementa paginação para lidar com um grande número de projetos:

*   **Configuração na View:**
    *   O atributo `paginate_by` na `ProjectListView` é definido (ex: `paginate_by = 6`), indicando quantos projetos devem ser exibidos por página.
        ```python
        class ProjectListView(ListView):
            # ...
            paginate_by = 6
            # ...
        ```
*   **Como o Django Lida:** O `ListView` do Django automaticamente cuida da lógica de dividir o queryset em páginas e fornecer o objeto `page_obj` e `is_paginated` para o contexto do template.
*   **Interface no Template (`project_list.html`):
    *   O template verifica se `is_paginated` é verdadeiro.
    *   Renderiza links para páginas anteriores/próximas (`page_obj.has_previous`, `page_obj.has_next`, `page_obj.previous_page_number`, `page_obj.next_page_number`).
    *   Renderiza números de página, geralmente com lógica para exibir um intervalo ao redor da página atual.
    *   Importante: Os links de paginação precisam incluir os parâmetros de filtro e ordenação atuais para que a navegação entre páginas mantenha o estado da busca/filtro. Isso é feito no template iterando sobre `request.GET.items` e adicionando-os aos links de paginação.
        ```html
        {% if page_obj.has_previous %}
            <a class="page-link" href="?page={{ page_obj.previous_page_number }}{% for key, value in request.GET.items %}{% if key != 'page' %}&{{ key }}={{ value }}{% endif %}{% endfor %}">Anterior</a>
        {% endif %}
        ```

### 3. Templates Dinâmicos e Herança

O projeto faz uso extensivo do sistema de templates do Django para criar páginas dinâmicas e reutilizáveis:

*   **Template Base (`templates/base.html`):
    *   Define a estrutura HTML principal comum a todas as páginas (ou a maioria delas), incluindo `<html>`, `<head>` (com links para CSS, Bootstrap, fontes), `<header>`, `<main>`, e `<footer>`.
    *   Utiliza blocos de template (`{% block %}` e `{% endblock %}`) para definir seções que podem ser sobrescritas por templates filhos.
        *   `{% block title %}Meu Portfólio{% endblock title %}`: Para o título da página.
        *   `{% block extra_head %}{% endblock extra_head %}`: Para adicionar CSS ou JS específico no head.
        *   `{% block content %}{% endblock content %}`: Onde o conteúdo principal de cada página é inserido.
        *   `{% block extra_js %}{% endblock extra_js %}`: Para adicionar JavaScript no final do body.
*   **Herança de Templates:**
    *   Templates específicos de apps (ex: `templates/projects/project_list.html`, `templates/core/home.html`) herdam do `base.html` usando a tag `{% extends 'base.html' %}` no início do arquivo.
    *   Eles então preenchem os blocos definidos no `base.html` com seu conteúdo específico.
        ```html
        {% extends 'base.html' %}
        {% load static %}
        {% load project_tags %}

        {% block title %}Lista de Projetos{% endblock title %}

        {% block content %}
            <!-- Conteúdo da lista de projetos aqui -->
        {% endblock content %}
        ```
*   **Inclusão de Templates (se usado):** Embora não explicitamente detalhado anteriormente, a tag `{% include 'path/to/template.html' %}` poderia ser usada para reutilizar pedaços menores de HTML em múltiplos templates (ex: um card de projeto).
*   **Variáveis de Contexto:** As views passam dados (objetos de modelo, formulários, etc.) para os templates através do dicionário de contexto. Esses dados são então renderizados dinamicamente usando `{{ variavel }}` ou processados com tags como `{% for %}` e `{% if %}`.
*   **Filtros de Template:** Utilizados para formatar variáveis (ex: `{{ project.data_criacao|date:"d/m/Y" }}`, `{{ project.descricao|truncatewords:20 }}`) e as tags personalizadas como `{{ project.tecnologias|join_technologies|safe }}`.

Essa abordagem promove um código mais limpo (DRY - Don't Repeat Yourself), facilita a manutenção e permite a construção de interfaces complexas de forma organizada.

## Configuração e Instalação

1.  **Clone o Repositório (Exemplo):**
    ```bash
    git clone https://github.com/seu_usuario/seu_repositorio.git
    cd seu_repositorio
    ```

2.  **Crie e Ative um Ambiente Virtual:**
    ```bash
    python -m venv venv
    # Windows
    .\venv\Scripts\activate
    # Linux/macOS
    source venv/bin/activate
    ```

3.  **Instale as Dependências:**
    ```bash
    pip install -r requirements.txt
    ```

4.  **Configure as Variáveis de Ambiente:**
    *   Copie `.env.example` para `.env`.
    *   Preencha `.env` com suas credenciais do PostgreSQL, `SECRET_KEY`, e `DEBUG=True` (para desenvolvimento).
        ```
        SECRET_KEY=sua_chave_secreta_super_forte
        DEBUG=True
        DB_NAME=seu_db_name
        DB_USER=seu_db_user
        DB_PASSWORD=sua_db_password
        DB_HOST=localhost
        DB_PORT=5432
        ```

5.  **Configure o Banco de Dados PostgreSQL:**
    *   Certifique-se que o PostgreSQL está instalado e rodando.
    *   Crie um banco de dados e um usuário com as credenciais definidas no passo anterior.

6.  **Aplique as Migrações:**
    ```bash
    python manage.py migrate
    ```

7.  **Crie um Superusuário:**
    *   Para usar o superusuário padrão (`admin`/`admin123`):
        ```bash
        python manage.py createsuperuser_custom
        ```
    *   Para criar um superusuário interativamente:
        ```bash
        python manage.py createsuperuser
        ```

8.  **Rode o Servidor de Desenvolvimento:**
    ```bash
    python manage.py runserver
    ```
    O site estará acessível em `http://127.0.0.1:8000/`.
    O painel admin estará em `http://127.0.0.1:8000/admin/`.

## Estrutura do Projeto

*   `manage.py`: Utilitário de linha de comando do Django.
*   `requirements.txt`: Dependências Python.
*   `.gitignore`: Especifica arquivos não versionados.
*   `.env.example`: Arquivo de exemplo para variáveis de ambiente.
*   `.env`: Arquivo (não versionado) com variáveis de ambiente reais.
*   `portfolio/`: Diretório de configuração do projeto Django (`settings.py`, `urls.py`, etc.).
*   `core/`: App Django para funcionalidades centrais (página inicial).
    *   `views.py`: Contém `HomePageView`.
    *   `urls.py`: URLs específicas do app core.
    *   `management/commands/createsuperuser_custom.py`: Comando para criar superusuário padrão.
*   `projects/`: App Django para funcionalidades dos projetos.
    *   `models.py`: Define os modelos `Tecnologia` e `Projeto`.
    *   `forms.py`: Contém `ProjetoForm`.
    *   `views.py`: Contém as Class-Based Views para o CRUD de Projetos.
    *   `admin.py`: Configuração da interface de administração para `Tecnologia` e `Projeto`.
    *   `urls.py`: URLs específicas do app projects.
    *   `templatetags/project_tags.py`: Contém as template tags `join_technologies` e `project_card_class`.
*   `templates/`: Diretório global de templates.
    *   `base.html`: Template principal.
    *   `core/home.html`: Template da página inicial.
    *   `projects/`: Templates para listagem, detalhes, formulário e exclusão de projetos.
*   `static/`: Diretório para arquivos estáticos globais.
    *   `css/style.css`: Folha de estilos customizada.
    *   `images/`: Placeholders de imagens.
*   `media/`: Diretório (criado dinamicamente) para uploads de mídia (ex: imagens de projetos).

Este README provê uma visão geral do projeto, suas funcionalidades, e um mergulho técnico em como os balões de tecnologia foram implementados, cobrindo o processo de desenvolvimento que seguimos. 